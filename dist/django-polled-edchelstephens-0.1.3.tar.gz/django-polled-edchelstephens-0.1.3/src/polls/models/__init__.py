from polls.models.abstract import *
from polls.models.question import *