The polls app was inspired and created after following the Django 3.1 Writing your first Django app Tutorial.

Link:
https://docs.djangoproject.com/en/3.1/intro/tutorial01/

-----------
Written with <3 by:
Edchel Stephen B. Nini
edchelstephens@gmail.com
https://pypi.org/user/edchelstephens/
https://github.com/edchelstephens
https://www.linkedin.com/in/edchelstephens/